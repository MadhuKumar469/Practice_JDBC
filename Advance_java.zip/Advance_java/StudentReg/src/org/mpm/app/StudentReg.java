package org.mpm.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/StudentReg")
public class StudentReg extends GenericServlet {

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
			
		String id=request.getParameter("reg");
		String name=request.getParameter("stuName");
		String mNum=request.getParameter("mNumber");
		String eMail=request.getParameter("eMail");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection= DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=12345");
			PreparedStatement preparedStatement=connection.prepareStatement("insert into demo.StudentReg values(?,?,?,?)");
			preparedStatement.setString(1, id);
			preparedStatement.setString(2, name);
			preparedStatement.setString(3, mNum);
			preparedStatement.setString(4, eMail);
			preparedStatement.executeUpdate();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		PrintWriter printWriter=response.getWriter();
		printWriter.println("Student ID:"+id);
		printWriter.println("Student Name:"+name);
		printWriter.println("Student Mobile Number:"+mNum);
		printWriter.println("Student Email ID:"+eMail);
		
	}

}
