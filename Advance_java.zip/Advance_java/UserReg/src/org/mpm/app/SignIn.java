package org.mpm.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/SignIn")
public class SignIn extends GenericServlet{

	String userName,dEmail,pass,dPhone;
	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		String eMailId=request.getParameter("userName");
		String password=request.getParameter("password");
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=12345");
			PreparedStatement preparedStatement=connection.prepareStatement("select * from demo.applicationuser where password=?");
			preparedStatement.setString(1, password);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				userName=resultSet.getString(1);
				dEmail=resultSet.getString(2);
				dPhone=resultSet.getString(3);
				pass=resultSet.getString(4);
			}
			PrintWriter writer=response.getWriter();
			if(eMailId.equals(dEmail) || eMailId.equals(dPhone)&& password.equals(pass))
			{
				writer.println("welcome to "+userName);
			}
			else
			{
				writer.println("Login Failed");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
