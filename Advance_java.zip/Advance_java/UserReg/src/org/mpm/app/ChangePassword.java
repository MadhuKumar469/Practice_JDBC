package org.mpm.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/ChangePassword")
public class ChangePassword extends GenericServlet{
	String dEMail;
	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		String eMailId=request.getParameter("eMailId");
		String password=request.getParameter("password");
		String cPassword=request.getParameter("cPassword");
		PrintWriter writer=response.getWriter();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=12345");
			PreparedStatement preparedStatement=connection.prepareStatement("update demo.applicationuser set password=? where EmailID=?");
			preparedStatement.setString(1, password);
			preparedStatement.setString(2, eMailId);
			PreparedStatement preparedStatement2=connection.prepareStatement("select * from demo.applicationuser where EmailId=?");
			preparedStatement2.setString(1, eMailId);
			ResultSet resultSet=preparedStatement2.executeQuery();
			while(resultSet.next())
			{
				dEMail=resultSet.getString(2);
			}
		    if(eMailId.equals(dEMail)&&cPassword.equals(password))
		    {
		    	preparedStatement.executeUpdate();
		    	writer.println("Password Changed Successfully");
		    }
		    else
		    {
		    	writer.println("Entered Data is Wrong");
		    }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}
