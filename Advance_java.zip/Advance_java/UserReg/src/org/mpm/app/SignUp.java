package org.mpm.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/SignUp")
public class SignUp extends GenericServlet{

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		String userName=request.getParameter("userName");
		String eMailId=request.getParameter("eMailId");
		String phoneNumber=request.getParameter("mNum");
		String password=request.getParameter("password");
		String cPassword=request.getParameter("cPassword");
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=12345");
			PreparedStatement preparedStatement=connection.prepareStatement("insert into demo.applicationuser values(?,?,?,?)");
			preparedStatement.setString(1, userName);
			preparedStatement.setString(2, eMailId);
			preparedStatement.setString(3, phoneNumber);
			preparedStatement.setString(4, password);
			if(password.equals(cPassword))
			{
				preparedStatement.executeUpdate();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		PrintWriter writer=response.getWriter();
		writer.println("Registration Successfull");
		
		
	}
	

}
