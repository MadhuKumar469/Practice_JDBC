package org.mpm.app;
/*write a JDBC program to display all card details from the database*/
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Program5 {
	public static void main(String[] args) {
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="select * from demo.carddetails";
		try {
			Connection connection=DriverManager.getConnection(url);
			Statement statement=connection.createStatement();
			ResultSet resultSet=statement.executeQuery(query);
			while(resultSet.next())
			{
				String cardnNmber=resultSet.getString("Card_Number");
				String typeOfCard=resultSet.getString("Type_Of_Card");
				String expiryDate=resultSet.getString("Expiry_Date");
				String cardHolderName=resultSet.getString("Card_Holder_Name");
				int ccv=resultSet.getInt("CCV");
				System.out.print(cardnNmber+" ");
				System.out.print(typeOfCard+" ");
				System.out.print(expiryDate+" ");
				System.out.print(cardHolderName+" ");
				System.out.print(ccv);
				System.out.println("");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
