package org.mpm.app;
/*write a JDBC program to retrieve Students information whose name starts with 'A' and store all information in Student class Object*/
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

public class StudentMain {
	public static void main(String[] args) throws IOException {
		FileReader fileReader=new FileReader("src/manishdata");
		Properties properties=new Properties();
		properties.load(fileReader);
		try {
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306",properties);
			PreparedStatement preparedStatement=connection.prepareStatement("select * from demo.studentinfo where name like 'A%'");
			ResultSet resultSet=preparedStatement.executeQuery();
			ArrayList<Student> arrayList=new ArrayList<Student>();
			while(resultSet.next())
			{
				int id=resultSet.getInt(1);
				String name=resultSet.getString(2);
				int marks=resultSet.getInt(3);
				Student student=new Student(id, name, marks);
				arrayList.add(student);
			}
			//Collections.sort(arrayList);
			Iterator<Student> iterator=arrayList.iterator();
			while(iterator.hasNext())
			{
				System.out.println(iterator.next());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
