package org.mpm.app;


import java.sql.SQLException;
import java.util.Scanner;

public class Libary_MainWay_1 {
	
	static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) throws SQLException 
	{
		String continueOption="YES";
		while(continueOption.equalsIgnoreCase("yes"))
		{
			System.out.println("WELCOME TO NATIONAL LIBARY\n1. Add the Book details\n2. Search for Book\n3. Updating Edition of Book\n4. Remove the Book");
			System.out.println("Please Enter above Option for further Process");
			int option=scanner.nextInt();
			switch (option) 
			{
			case 1:
					LibaryWay_1.addBook();
					System.out.println("Book successfully added");
					break;
			case 2:
					LibaryWay_1.searchBook();
					break;
			case 3:
					LibaryWay_1.updateBookEdition();
					System.out.println("Book Edition is Updated");
					break;
			case 4: 
					LibaryWay_1.removeBook();
					System.out.println("Book succesfully removed");
					break;
			}
			System.out.println("Enter YES/NO to Continue");
			continueOption=scanner.next();
		}
		if(continueOption.equalsIgnoreCase("NO"))
		{
			System.out.println("Thank You");
		}
	}

}
