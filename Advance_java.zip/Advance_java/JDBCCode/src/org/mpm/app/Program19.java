package org.mpm.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Program19 {
 static String us,email,pn,ps;
	static Scanner scanner=new Scanner(System.in);

public static void main(String[] args) {
	String q="insert into demo.applicationuser values(?,?,?,?)";
	String q1="insert into demo.applicationuser values(?,?,?,?)";
	try {
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=12345");
		connection.setAutoCommit(false);
		PreparedStatement preparedStatement=connection.prepareStatement(q);
		PreparedStatement preparedStatement2=connection.prepareStatement(q1);
		//Program19 program19 =new Program19();
		scanner();
		preparedStatement.setString(1, us);
		preparedStatement.setString(2, email);
		preparedStatement.setString(3, pn);
		preparedStatement.setString(4, ps);
		preparedStatement.executeUpdate();
		scanner();
		preparedStatement2.setString(1,us);
		preparedStatement2.setString(2,email);
		preparedStatement2.setString(3,pn);
		preparedStatement2.setString(4,ps);
		preparedStatement2.executeUpdate();
		
		connection.commit();
		System.out.println("completed....");
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
public static void scanner()
{
	System.out.println("enter username");
	us=scanner.next();
	System.out.println("enter mail");
	email=scanner.next();
	System.out.println("Enter phone number");
	pn=scanner.next();
	System.out.println("enter password");
	ps=scanner.next();
}
}
