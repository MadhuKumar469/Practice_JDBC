package org.mpm.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/*Write a JDBC program to check whether given card number does exist or not in the database*/
public class Program7 {
 public static void main(String[] args) {
	 String url="jdbc:mysql://localhost:3306?user=root&password=12345";
	 String query="select * from demo.carddetails where Card_number='1234 5678 9874 4562'";
	try {
		Connection connection =DriverManager.getConnection(url);
		Statement statement=connection.createStatement();
		ResultSet resultSet=statement.executeQuery(query);
		if(resultSet.next())
		{
			String cardnNmber=resultSet.getString("Card_Number");
			String typeOfCard=resultSet.getString("Type_Of_Card");
			String expiryDate=resultSet.getString("Expiry_Date");
			String cardHolderName=resultSet.getString("Card_Holder_Name");
			int ccv=resultSet.getInt("CCV");
			System.out.print(cardnNmber+" ");
			System.out.print(typeOfCard+" ");
			System.out.print(expiryDate+" ");
			System.out.print(cardHolderName+" ");
			System.out.print(ccv);
		}
		else
		{
			System.out.println("You entered card details are not avalible");
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
