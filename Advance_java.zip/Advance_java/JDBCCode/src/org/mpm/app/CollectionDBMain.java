package org.mpm.app;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

public class CollectionDBMain {
	public static void main(String[] args) throws IOException {
		FileReader fileReader=new FileReader("src/manishdata");
		Properties properties=new Properties();
		properties.load(fileReader);
		try {
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306",properties);
			PreparedStatement preparedStatement=connection.prepareStatement("select * from demo.libarybook");
			ResultSet resultSet=preparedStatement.executeQuery();
			List<Object> arrayList=new ArrayList<Object>();
			while(resultSet.next())
			{
				String bookName=resultSet.getString("BookTitle");
				String bookAuthor=resultSet.getString("BookAuthor");
				int edition=resultSet.getInt("Edition");
				int price=resultSet.getInt("Price");
				String bookType=resultSet.getString("BookType");
				CollectionDB collectionDB=new CollectionDB(bookName, bookAuthor, edition, price, bookType);
				arrayList.add(collectionDB);
			}
			Iterator<Object> iterator=arrayList.iterator();
			while(iterator.hasNext())
			{
				System.out.println(iterator.next());
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}
}