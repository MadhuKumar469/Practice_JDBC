package org.mpm.app;
/*write JDBC to adding three product information into productdetails table*/
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Program3 {
	public static void main(String[] args) {
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		
		String query="insert into demo.productdetails values(12345678,'food','KFC','2021-02-01','2021-04-30','yes')";
		String query1="insert into demo.productdetails values(12345658,'Clothes','MAX','2021-02-01','2021-03-31','yes')";
		String query2="insert into demo.productdetails values(12345668,'Moblie','MI','2021-02-01','2022-01-31','yes')";

		try 
		{
			Connection connection=DriverManager.getConnection(url);
			System.out.println("step 1");
			Statement statement=connection.createStatement();
			System.out.println("step2");
			statement.executeUpdate(query);
			statement.executeUpdate(query1);
			statement.executeUpdate(query2);
			System.out.println("step3");
			connection.close();
			System.out.println("step 5");
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
}
