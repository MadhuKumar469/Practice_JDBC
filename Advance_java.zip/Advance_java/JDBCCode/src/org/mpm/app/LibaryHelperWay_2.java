package org.mpm.app;

public class LibaryHelperWay_2 {
	public static LibaryWay_2 libaryHelper()
	{
		LibaryWay_2 libaryWay_2=new LibaryWay_2();
		return libaryWay_2;
	}

}
