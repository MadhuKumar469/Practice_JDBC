package org.mpm.app;
/*write JDBC  to remove one product information from product details table*/
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Program4 {
	public static void main(String[] args) {
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		
		String query="delete from demo.productdetails where product_id=12345678";
		
		try 
		{
			Connection connection=DriverManager.getConnection(url);
			System.out.println("step 1");
			Statement statement=connection.createStatement();
			System.out.println("step2");
			statement.executeUpdate(query);
			System.out.println("step3");
			connection.close();
			System.out.println("step 5");
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
}
