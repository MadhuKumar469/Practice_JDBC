package org.mpm.app;
import java.util.Scanner;
public class Program13
{
	static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) 
	{
		wish();
		
		System.out.println("Enter YES/NO to continue");
		String continueOption=scanner.next();
		if(continueOption.equalsIgnoreCase("yes"))
		{
			wish();
		}
		else
		{
			System.err.println("Thank You");
		}
	}	
	public static void wish()
	{
		System.out.println("WELCOME TO INFO APPLICATION");
		System.out.println("Please Select given option\n1. SignIn\n2. SignUp\n3. Change Password");
		
		String option=scanner.next();
		switch (option) {
		case "1":
			 	Program12.signIn();
			 	break;
		case "2":
				Program9.signUp();
				break;
		case "3": 
				Program10.changePassword();
				break;
		default:
			break;
		}
	}
}

		

