package org.mpm.app;


import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Program20 {
public static void main(String[] args) throws IOException {
	FileReader fileReader=new FileReader("src/manishdata");
	Properties properties=new Properties();
	properties.load(fileReader);
	System.out.println(properties.getProperty("user"));
	System.out.println(properties.getProperty("password"));
	
}
}
