package org.mpm.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class LibaryWay_1
{	
	static String url="jdbc:mysql://localhost:3306?user=root&password=12345";
	static Connection connection=null;
	static Scanner scanner = new Scanner(System.in);
	public static void connectionFailedException() {
		try
		{
			 connection=DriverManager.getConnection(url);    
			 
		}
		catch (SQLException exception) {
			System.out.println("Connection failed");
		}
	}  
	public static void addBook() throws SQLException
	{
			String query="insert into demo.libarybook values(?,?,?,?,?)";
			connectionFailedException();
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			System.out.println("Enter Book Title");
			String bookTitle=scanner.nextLine();
			System.out.println("Enter respective Author of Book");
			String bookAuthor=scanner.nextLine();
			System.out.println("Enter respective Edition of Book");
			int edition =scanner.nextInt();
			System.out.println("Enter Book Price");
			int bookPrice=scanner.nextInt();
			System.out.println("Enter Type of Book");
			String bookType=scanner.next();
			preparedStatement.setString(1, bookTitle);
			preparedStatement.setString(2, bookAuthor);
			preparedStatement.setInt(3, edition);
			preparedStatement.setInt(4, bookPrice);
			preparedStatement.setString(5, bookType);
			preparedStatement.executeUpdate();
	}
	public static void searchBook() throws SQLException
	{
			String qurey="select * from demo.libarybook where Booktitle=?";
			connectionFailedException();
			PreparedStatement preparedStatement=connection.prepareStatement(qurey);
			System.out.println("Enter Book Title");
			String bookTitle=scanner.nextLine();
			preparedStatement.setString(1, bookTitle);
			preparedStatement.executeQuery();
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				String bookName=resultSet.getString(1);
				String bookAuthor=resultSet.getString(2);
				int edition=resultSet.getInt(3);
				int price=resultSet.getInt(4);
				String bookType=resultSet.getString(5);
				System.out.println("Book details:");
				System.out.println(bookName+"   "+bookAuthor+"   "+edition+"   "+price+"   "+bookType);
			}
			//scanner.close();		
	}
	public static void updateBookEdition() throws SQLException
	{
			String query="update demo.libarybook set Edition=? where BookTitle=?";
			connectionFailedException();
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			System.out.println("Enter Book Title");
			String bookTitle=scanner.nextLine();
			System.out.println("Enter New Edition");
			String edition=scanner.next();
			preparedStatement.setString(1, edition);
			preparedStatement.setString(2, bookTitle);
			preparedStatement.executeUpdate();
			//scanner.close();
	}
	public static void removeBook() throws SQLException
	{
			String query="delete from demo.libarybook where BookTitle=?";
			connectionFailedException();
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			System.out.println("Enter Book Title");
			String bookTitle=scanner.nextLine();
			preparedStatement.setString(1, bookTitle);
			preparedStatement.executeUpdate();
			//scanner.close();	
	}
	
	
}
