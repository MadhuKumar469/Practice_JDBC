package org.mpm.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Program8 {
	public static void main(String[] args) {
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="select * from demo.productdetails";
		try {
			Connection connection=DriverManager.getConnection(url);
			Statement statement=connection.createStatement();
			ResultSet resultSet=statement.executeQuery(query);
			while(resultSet.next())
			{
				int product_Id=resultSet.getInt("Product_Id");
				String product_Name=resultSet.getString("Product_Type");
				String product_Manufacture=resultSet.getString("Product_Manufacture");
				String manufacture_Date=resultSet.getString("Manufacture_Date");
				String expiry_Date=resultSet.getString("Expiry_Date");
				String avaliable=resultSet.getString("Avability");
				System.out.print(product_Id+" ");
				System.out.print(product_Name+" ");
				System.out.print(product_Manufacture+" ");
				System.out.print(manufacture_Date+" ");
				System.out.print(expiry_Date+" ");
				System.out.println(avaliable);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
