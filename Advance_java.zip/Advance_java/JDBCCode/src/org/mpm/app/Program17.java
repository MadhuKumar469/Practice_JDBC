package org.mpm.app;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Program17 {
public static void main(String[] args) {
	String url="jdbc:mysql://localhost:3306?user=root&password=12345";
	String query= "{call demo.Sp4(?)}";
	try {
		Connection connection=DriverManager.getConnection(url);
		CallableStatement callableStatement=connection.prepareCall(query);
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter email");
		String email=scanner.next();
		callableStatement.setString(1, email);
		ResultSet resultSet=callableStatement.executeQuery();
		while(resultSet.next())
		{
			String uname=resultSet.getString("userName");
			String mail=resultSet.getString("EmailId");
			String pn=resultSet.getString("PhoneNumber");
			String pass=resultSet.getString("Password");
			System.out.print(uname+" ");
			System.out.print(mail+" ");
			System.out.print(pn+" ");
			System.out.print(pass);
			System.out.println("");
		}
		scanner.close();
		connection.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
