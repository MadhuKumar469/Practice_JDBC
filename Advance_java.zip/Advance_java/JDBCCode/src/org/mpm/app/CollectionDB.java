package org.mpm.app;

public class CollectionDB {
	String bookName,bookAuthor,bookType;
	int edition,price;
	public CollectionDB(String bookName, String bookAuthor, int edition, int price, String bookType) {
		super();
		this.bookName = bookName;
		this.bookAuthor = bookAuthor;
		this.edition = edition;
		this.price = price;
		this.bookType = bookType;
	}
	@Override
	public String toString() {
		return "CollectionDB [bookName=" + bookName + ", bookAuthor=" + bookAuthor + ", bookType=" + bookType
				+ ", edition=" + edition + ", price=" + price + "]";
	}
	
}
