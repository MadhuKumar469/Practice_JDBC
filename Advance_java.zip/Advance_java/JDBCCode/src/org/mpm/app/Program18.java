package org.mpm.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Program18 {
public static void main(String[] args) {
	String q="insert into demo.applicationuser values('m mmmm','madhukumar@gmail.com','7410852963','mkiujn12')";
	String q1="insert into demo.applicationuser values('k kkkk','kumar@gmail.com','1234567890','mnbvc123')";
	try {
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=12345");
		connection.setAutoCommit(false);
		Statement statement=connection.createStatement();
		statement.executeUpdate(q);
		statement.executeUpdate(q1);
		connection.commit();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
