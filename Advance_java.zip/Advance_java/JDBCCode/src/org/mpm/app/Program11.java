package org.mpm.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Program11 
{
	public static void main(String[] args) {
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="select * from demo.applicationuser";
		String query1="select userName from demo.applicationuser where EmailId=? and Password=?";
		try {
			Connection connection=DriverManager.getConnection(url);
			PreparedStatement preparedStatement=connection.prepareStatement(query1);
			Scanner scanner=new Scanner(System.in);
			System.out.println("enter your emailId");
			String emailId=scanner.next();
			System.out.println("Enter your password");
			String password=scanner.next();
			Statement statement=connection.createStatement();
			ResultSet resultSet=statement.executeQuery(query);
			int count=0;
			while(resultSet.next())
			{
				String databaseEmail=resultSet.getString("EmailId");
				String databasePassword =resultSet.getString("Password");
				String name=resultSet.getString("userName");
				if((emailId.equals(databaseEmail))&& (password.equals(databasePassword)))
				{
					preparedStatement.setString(1, emailId);
					preparedStatement.setString(2, password);
					
					System.out.println("WELCOME TO "+name);
					count++;
				}
			}
			if(count==0)
			{
					System.out.println("Login Unsuccessful...");
			}
			connection.close();
			scanner.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
