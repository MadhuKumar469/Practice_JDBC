package org.mpm.app;
/*Write a JDBC program to retrieve employee information from table and store all information in employee class object and display the all employee details*/
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Properties;
import java.util.TreeSet;

public  class EmployeeMain {
	
	public static void main(String[] args) throws IOException {
		FileReader fileReader=new FileReader("src/manishdata");
		Properties properties=new Properties();
		properties.load(fileReader);
		try {
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306",properties);
			PreparedStatement preparedStatement=connection.prepareStatement("select * from demo.employeeinfo");
			ResultSet resultSet=preparedStatement.executeQuery();
			//ArrayList<Employee> arrayList=new ArrayList<Employee>();
			TreeSet<Employee> t = new TreeSet<Employee>();

			while(resultSet.next())
			{
				int id=resultSet.getInt("Id");
				String name=resultSet.getString("Name");
				String job=resultSet.getString("Job");
				double salary=resultSet.getDouble("Salary");
				Employee employee=new Employee(id, name, job, salary);
				t.add(employee);
			}
			//Collections.sort(arrayList);
			
			Iterator<Employee> iterator=t.iterator();
			while(iterator.hasNext())
			{
				System.out.println(iterator.next());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block  
			e.printStackTrace();
		}
		
	}

}
