package org.mpm.app;
/*Write a JDBC program to enter the user of application*/
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
public class Program9 
{
	static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) 
	{
		signUp();
	}
	public static void signUp()
	{
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="insert into demo.applicationuser values(?,?,?,?)";
		try {
			Connection connection=DriverManager.getConnection(url);
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			
			System.out.println("Enter User Name");
			String userName=scanner.next();
			System.out.println("Enter Email ID");
			String emailId=scanner.next();
			System.out.println("Enter Phone Number");
			String phoneNumber=scanner.next();
			System.out.println("Enter Password");
			String password=scanner.next();
			System.out.println("Enter Confirm Password");
			String confirmPassword=scanner.next();
			preparedStatement.setString(1, userName);
			preparedStatement.setString(2, emailId);
			preparedStatement.setString(3, phoneNumber);
			preparedStatement.setString(4, password);
			if(password.equals(confirmPassword))
			{
				preparedStatement.executeUpdate();
				System.out.println("Registration Successfull");
			}
			else
			{
				System.out.println("Password Mismatch...");
			}
			connection.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
}
