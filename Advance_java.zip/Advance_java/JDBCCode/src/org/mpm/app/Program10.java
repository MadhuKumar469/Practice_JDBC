package org.mpm.app;
/*Write a JDBC program to update password of user of application*/
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class Program10
{
	public static void main(String[] args) 
	{
		changePassword();
	}
	public static void changePassword()
	{
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		String query="update demo.applicationuser set password=? where EmailId=?";
		String query1="select EmailId from demo.applicationuser";
		//String query2="select password from demo.applicationuser";
		try {
			Connection connection=DriverManager.getConnection(url);
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			Scanner scanner=new Scanner(System.in);
			System.out.println("Enter emailId");
			String emailId=scanner.next();
			String databaseEmailId="";
			Statement statement=connection.createStatement();
			ResultSet resultSet=statement.executeQuery(query1);
			int count=0;
			while(resultSet.next())
			{
				databaseEmailId=resultSet.getString("EmailId");	
				if(emailId.equals(databaseEmailId))
				{
					System.out.println("Enter New Password");
					String password=scanner.next();
					System.out.println("Enter Confirm New Password");
					String confirmPassword=scanner.next();
					preparedStatement.setString(1, password);
					preparedStatement.setString(2, emailId);
					if(password.equals(confirmPassword))
					{
						preparedStatement.executeUpdate();
						System.out.println("password changed Successfull");
						count++;
					}
					else
					{
						System.out.println("password mismatch");
					}
				}
			}
			if(count==0)
			{
				System.out.println("invalid emailid");
			}	
			resultSet.close();
			connection.close();
			
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
	}
}
