package org.mpm.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/*write JDBC program for upadating expiry date of card holder*/
public class Program2 {

	public static void main(String[] args) 
	{
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";
		
		String query="update demo.carddetails set expiry_date='2035-12-31' where CCV=123";
		try 
		{
			Connection connection=DriverManager.getConnection(url);
			System.out.println("step 1");
			Statement statement=connection.createStatement();
			
			statement.executeUpdate(query);
			connection.close();
			System.out.println("step 5");
		}
		catch (SQLException e)
		{	
			e.printStackTrace();
		}
	}
}


