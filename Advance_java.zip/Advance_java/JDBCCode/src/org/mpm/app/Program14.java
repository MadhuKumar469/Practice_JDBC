package org.mpm.app;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class Program14 {
public static void main(String[] args) {
	String url="jdbc:mysql://localhost:3306?user=root&password=12345";
	String query= "{call demo.Sp1(?,?,?,?)}";
	try {
		Connection connection=DriverManager.getConnection(url);
		CallableStatement callableStatement=connection.prepareCall(query);
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter username");
		String userName=scanner.next();
		System.out.println("Enter EmailId");
		String email=scanner.next();
		System.out.println("Enter phonenumber");
		String pn=scanner.next();
		System.out.println("Enter the password");
		String pa=scanner.next();
		callableStatement.setString(1, userName);
		callableStatement.setString(2, email);
		callableStatement.setString(3, pn);
		callableStatement.setString(4, pa);
		callableStatement.executeUpdate();
		System.out.println("successfully done");
		scanner.close();
		connection.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
}
}
