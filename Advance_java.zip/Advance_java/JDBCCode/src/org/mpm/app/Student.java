package org.mpm.app;

public class Student {
int id,marks;
String name;
public Student(int id, String name,int marks) {
	super();
	this.id = id;
	this.marks = marks;
	this.name = name;
}
@Override
public String toString() {
	return "Student [id=" + id + ", marks=" + marks + ", name=" + name + "]";
}


}
