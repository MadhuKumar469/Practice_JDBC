package org.mpm.app;
/*Write JDBC program for adding carddetails into carddetails table*/
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Program1 {
	public static void main(String[] args) {
		String url="jdbc:mysql://localhost:3306?user=root&password=12345";	
		String query="insert into demo.carddetails values('9516 2347 8964 ','DC','2034-12-31','MADHU PAVAN MANISH',321)";
		try 
		{
			Connection connection=DriverManager.getConnection(url);
			System.out.println("step 1");
			Statement statement=connection.createStatement();
			statement.executeUpdate(query);
			connection.close();
			System.out.println("step 5");
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
}
