package org.mpm.app;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class Program16 {
public static void main(String[] args) {
	String url="jdbc:mysql://localhost:3306?user=root&password=12345";
	String query= "{call demo.Sp3(?)}";
	try {
		Connection connection=DriverManager.getConnection(url);
		CallableStatement callableStatement=connection.prepareCall(query);
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter username");
		String us=scanner.next();
		callableStatement.setString(1, us);
		callableStatement.executeUpdate();
		System.out.println("delete Successfully");
		scanner.close();
		connection.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
