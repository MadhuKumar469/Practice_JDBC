package org.mpm.app;

import java.io.IOException;
import java.util.Random;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/GenerateOTPProgram")
public class GenerateOTPProgram extends GenericServlet{

	@Override
	public void service(ServletRequest arg0, ServletResponse arg1) throws ServletException, IOException {
		Random random =new Random();
		int otp=random.nextInt(1000000);
		String s1=""+otp;
		if(otp<0)
		{
			otp=otp*-1;
		}
		switch (s1.length()) {
		case 1: {
			
			        otp=otp*100000;
			        break;
		        }
		case 2: {
			
	        		otp=otp*10000;
	        		break;
				}
		case 3: {
			
					otp=otp*1000;
					break;
        		}
		case 4: {
			
					otp=otp*100;
					break;
				}
		case 5: {
			
					otp=otp*10;
					break;
				}
		
		}
		System.out.println(otp);
	}
}