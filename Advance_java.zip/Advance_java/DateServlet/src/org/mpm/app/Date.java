package org.mpm.app;

import java.io.IOException;
import java.text.SimpleDateFormat;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/Date")
public class Date extends GenericServlet {

	@Override
	public void service(ServletRequest arg0, ServletResponse arg1) throws ServletException, IOException {
		// TODO Auto-generated method stub
		java.util.Date date=new java.util.Date();
		System.out.println(date);
		SimpleDateFormat dateFormat=new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		System.out.println(dateFormat.format(date));
	}
	

}
