package org.mpm.app;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/Connection")
public class Connection extends GenericServlet{

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		String tConnection=request.getParameter("typeOfConnection");
		String sName=request.getParameter("sName");
		String cDuration=request.getParameter("Duration");
		int duration=Integer.parseInt(cDuration);
		PrintWriter printWriter=response.getWriter();
		if("Prepaid".equals(tConnection))
		{
			switch (sName) {
			case "Local": {
				
				int total=duration*200+75;
				printWriter.println("The Total Monthly Rental Cost is: "+total);
				break;
			}
			case "STD": {
				
				int total =duration*350+75;
				printWriter.println("The Total Monthly Rental Cost is: "+total);
				break;
			}
			case "Full Talk Time": {
				
				int total=duration*500+75;
				printWriter.println("The Total Monthly Rental Cost is: "+total);
				break;
			}
			}
		}
		else if("Postpaid".equals(tConnection))
		{
			switch (sName) {
			case "Local": {
				
				int total=duration*200+150;
				printWriter.println("The Total Monthly Rental Cost is: "+total);
				break;
			}
			case "STD": {
				
				int total =duration*350+150;
				printWriter.println("The Total Monthly Rental Cost is: "+total);
				break;
			}
			case "Full Talk Time": {
				
				int total=duration*500+150;
				printWriter.println("The Total Monthly Rental Cost is: "+total);
				break;
			}
			}
		}
	}

}
