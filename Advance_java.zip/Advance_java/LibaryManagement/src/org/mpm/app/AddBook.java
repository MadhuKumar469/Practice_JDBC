package org.mpm.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/AddBook")
public class AddBook extends GenericServlet{

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		String title=request.getParameter("title");
		String author=request.getParameter("author");
		String edition=request.getParameter("edition");
		String price=request.getParameter("price");
		String type=request.getParameter("type");
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=12345");
			PreparedStatement preparedStatement=connection.prepareStatement("insert into demo.libarybook values(?,?,?,?,?)");
			preparedStatement.setString(1, title);
			preparedStatement.setString(2, author);
			preparedStatement.setString(3, edition);
			preparedStatement.setString(4, price);
			preparedStatement.setString(5, type);
			preparedStatement.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PrintWriter writer=response.getWriter();
		writer.println("Title: "+title);
		writer.println("Author: "+author);
		writer.println("Edition: "+edition);
		writer.println("Price: "+price);
		writer.println("Type: "+type);
		
		
	}

	
}
