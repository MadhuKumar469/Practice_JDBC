package org.mpm.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/SearchBook")
public class SearchBook extends GenericServlet{

	static String title,author,edition,price,type;
	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		String title=request.getParameter("title");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=12345");
			PreparedStatement preparedStatement=connection.prepareStatement("select * from demo.libarybook where BookTitle=?");
			preparedStatement.setString(1, title);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				title=resultSet.getString(1);
				author=resultSet.getString(2);
				edition=resultSet.getString(3);
				price=resultSet.getString(4);
				type=resultSet.getString(5);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PrintWriter writer =response.getWriter();
		writer.println("Title: "+title);
		writer.println("Author: "+author);
		writer.println("Edition: "+edition);
		writer.println("Price: "+price);
		writer.println("Type: "+type);
	}

}
